using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text;
using System.Net;

[Route("api/[controller]")]
[ApiController]
public class F5AsmController : ControllerBase
{
    private readonly HttpClient _client;

    public F5AsmController(IHttpClientFactory clientFactory)
    {
        _client = clientFactory.CreateClient();
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        _client.BaseAddress = new Uri("https://10.1.1.11");
        var byteArray = Encoding.ASCII.GetBytes("admin:kailas@123");
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
    }

    [HttpGet("policies")]
    public async Task<IActionResult> GetAsmPolicies()
    {
        var result = new List<object>();
        var response = await _client.GetAsync("/mgmt/tm/asm/policies?$select=name,id,enforcementMode");
        if (!response.IsSuccessStatusCode) return StatusCode((int)response.StatusCode, "Failed to fetch policies.");

        var json = await response.Content.ReadAsStringAsync();
        var root = JsonDocument.Parse(json);
        var items = root.RootElement.GetProperty("items");

        foreach (var policy in items.EnumerateArray())
        {
            var id = policy.GetProperty("id").GetString();
            var name = policy.GetProperty("name").GetString();
            var enforcementMode = policy.GetProperty("enforcementMode").GetString();

            var detailedResp = await _client.GetAsync($"/mgmt/tm/asm/policies/{id}?$select=virtualServers,manualVirtualServers");
            string directVips = "None", manualVips = "None";

            if (detailedResp.IsSuccessStatusCode)
            {
                var detailJson = await detailedResp.Content.ReadAsStringAsync();
                var detail = JsonDocument.Parse(detailJson).RootElement;

                if (detail.TryGetProperty("virtualServers", out var vsv)) directVips = string.Join(", ", vsv.EnumerateArray().Select(v => v.GetString()));
                if (detail.TryGetProperty("manualVirtualServers", out var mvsv)) manualVips = string.Join(", ", mvsv.EnumerateArray().Select(v => v.GetString()));
            }

            result.Add(new
            {
                policy_name = name,
                enforcement_mode = enforcementMode,
                direct_vips = directVips,
                manual_vips = manualVips
            });
        }

        return Ok(result);
    }
}
